# LEAGUE MAX Mods — Android Floating Overlay

A standalone Android utility with a draggable floating panel, collapse/expand bubble, visual-only ESP sample, overlay FPS/memory indicators, and opacity/scale controls.

**The ESP is illustrative only.** This app does not inspect, inject into, automate, or modify League Max or any other app's process, memory, graphics, or network traffic.

## Build configuration

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk: 35
- targetSdk: 35
- minSdk: 23
- Java: 17
- Dependencies: Android SDK only
- Package: `com.leaguemax.mods`

## Build locally

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Build using GitHub Actions from a phone

1. Create or open a GitHub repository.
2. Upload this ZIP to the repository root. The ZIP filename can be any `.zip` name.
3. Copy `.github/workflows/build.yml` from this project into the same path in the repository. GitHub must see it as `.github/workflows/build.yml` outside the ZIP.
4. Open the repository's Actions tab.
5. Run **Build LEAGUE MAX Mods APK**.
6. Download the `LEAGUE-MAX-Mods-APK` artifact after the job succeeds.

The workflow also supports uploading the extracted project files directly to the repository root instead of a ZIP.

## Install on Android

1. Install the generated `app-debug.apk`.
2. Open LEAGUE MAX Mods.
3. Tap **ACTIVATE FLOATING MENU**.
4. Allow **Display over other apps** in Android settings.
5. Return to the app and tap **ACTIVATE FLOATING MENU** again.
6. Use the floating panel. The notification indicates that its foreground service is running.

## Notes

- Overlay FPS measures this utility's frame callback, not the game's FPS.
- Memory reports this utility process's PSS, not the game's memory.
- The app is Java-only; Android will run it on ARM64 Motorola devices without a native ABI build.
- On Android 8.0+, the overlay uses `TYPE_APPLICATION_OVERLAY`.
- On Android 14+, the foreground service declares the `specialUse` type and its subtype.
