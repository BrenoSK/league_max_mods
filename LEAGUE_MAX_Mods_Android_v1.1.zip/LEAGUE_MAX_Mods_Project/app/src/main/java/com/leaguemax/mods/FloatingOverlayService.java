package com.leaguemax.mods;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Debug;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

public final class FloatingOverlayService extends Service implements Choreographer.FrameCallback {
    private static final String CHANNEL_ID = "league_max_overlay";
    private static final int NOTIFICATION_ID = 7101;
    private static final int PANEL_COLOR = 0xF0141712;
    private static final int ACCENT = 0xFFB8F35A;

    private WindowManager windowManager;
    private WindowManager.LayoutParams panelParams;
    private LinearLayout panel;
    private View bubble;
    private TextView statsText;
    private DemoEspView demoEspView;

    private boolean showEsp = true;
    private boolean showStats = true;
    private boolean expanded = true;
    private float panelAlpha = 0.96f;
    private float panelScale = 1.0f;
    private int savedX;
    private int savedY;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long previousFrameNanos;
    private int frameCount;
    private float overlayFps;
    private Runnable statsRunnable;

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        createPanel();
        Choreographer.getInstance().postFrameCallback(this);
        startStatsLoop();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "LEAGUE MAX Mods overlay",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Notification for the user-started floating utility overlay");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("LEAGUE MAX Mods")
                .setContentText("Floating utility menu is active")
                .setOngoing(true)
                .build();
    }

    private WindowManager.LayoutParams newOverlayParams(int width, int height) {
        int windowType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(
                width,
                height,
                windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
    }

    private int panelWidth() {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        return Math.min(dp(292), Math.max(dp(240), screenWidth - dp(24)));
    }

    private int panelHeight() {
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        return Math.min(dp(440), Math.max(dp(300), screenHeight - dp(120)));
    }

    private void createPanel() {
        panel = buildPanel();
        panelParams = newOverlayParams(
                Math.round(panelWidth() * panelScale),
                Math.round(panelHeight() * panelScale)
        );
        panelParams.gravity = Gravity.TOP | Gravity.LEFT;
        panelParams.x = savedX == 0 ? dp(16) : savedX;
        panelParams.y = savedY == 0 ? dp(100) : savedY;
        panel.setAlpha(panelAlpha);
        windowManager.addView(panel, panelParams);
        expanded = true;
    }

    private LinearLayout buildPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(1), dp(1), dp(1), dp(1));
        outer.setBackground(roundRect(PANEL_COLOR, dp(16), 0xFF343B2E));
        outer.setElevation(dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(13), dp(9), dp(8), dp(9));
        header.setBackground(roundRect(0xFF20251C, dp(14), 0xFF343B2E));

        TextView title = makeText("LEAGUE MAX Mods", 14, 0xFFF2F4EC, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView collapse = makeAction("—");
        collapse.setContentDescription("Minimize floating menu");
        collapse.setOnClickListener(v -> collapsePanel());
        header.addView(collapse, new LinearLayout.LayoutParams(dp(34), dp(32)));

        TextView close = makeAction("×");
        close.setContentDescription("Close floating menu");
        close.setOnClickListener(v -> stopSelf());
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(34), dp(32));
        closeParams.leftMargin = dp(5);
        header.addView(close, closeParams);
        header.setOnTouchListener(new PanelDragListener());
        outer.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(14));

        addSection(content, "VISUAL DEMO", 0);
        Switch espSwitch = makeSwitch("ESP sample boxes", showEsp, checked -> {
            showEsp = checked;
            if (demoEspView != null) demoEspView.setVisibility(checked ? View.VISIBLE : View.GONE);
        });
        content.addView(espSwitch);

        demoEspView = new DemoEspView(this);
        demoEspView.setVisibility(showEsp ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams espParams = new LinearLayout.LayoutParams(-1, dp(118));
        espParams.topMargin = dp(7);
        content.addView(demoEspView, espParams);

        addSection(content, "PERFORMANCE", 14);
        Switch statsSwitch = makeSwitch("Overlay FPS and memory", showStats, checked -> {
            showStats = checked;
            if (statsText != null) statsText.setVisibility(checked ? View.VISIBLE : View.GONE);
        });
        content.addView(statsSwitch);
        statsText = makeText("Overlay FPS: measuring…\nOverlay memory: measuring…", 12, 0xFFD4D8CD, false);
        addSpaced(content, statsText, 5, 2);

        addSection(content, "ADJUSTMENTS", 12);
        addSlider(content, "Panel opacity", 35, 100, Math.round(panelAlpha * 100), value -> {
            panelAlpha = value / 100.0f;
            if (panel != null) panel.setAlpha(panelAlpha);
        });
        addSlider(content, "Panel scale", 75, 125, Math.round(panelScale * 100), value -> {
            panelScale = value / 100.0f;
            updatePanelSize();
        });

        TextView footer = makeText("Local visual demo · no game process access", 10, 0xFF858B7D, false);
        addSpaced(content, footer, 12, 0);
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return outer;
    }

    private void addSection(LinearLayout parent, String label, int topMargin) {
        TextView section = makeText(label, 10, ACCENT, true);
        addSpaced(parent, section, topMargin, 5);
    }

    private GradientDrawable roundRect(int fill, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private TextView makeText(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private TextView makeAction(String value) {
        TextView action = makeText(value, 20, 0xFFE9EDE2, true);
        action.setGravity(Gravity.CENTER);
        action.setBackground(roundRect(0xFF30372A, dp(9), 0xFF414A38));
        return action;
    }

    private void addSpaced(LinearLayout parent, View view, int top, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(top);
        params.bottomMargin = dp(bottom);
        parent.addView(view, params);
    }

    private interface BooleanCallback {
        void onChanged(boolean value);
    }

    private Switch makeSwitch(String label, boolean initial, BooleanCallback callback) {
        Switch control = new Switch(this);
        control.setText(label);
        control.setTextColor(0xFFE1E5D9);
        control.setTextSize(12);
        control.setChecked(initial);
        control.setOnCheckedChangeListener((button, checked) -> callback.onChanged(checked));
        return control;
    }

    private interface IntegerCallback {
        void onChanged(int value);
    }

    private void addSlider(LinearLayout parent, String label, int min, int max, int initial, IntegerCallback callback) {
        int safeInitial = Math.max(min, Math.min(max, initial));
        TextView caption = makeText(label + " · " + safeInitial + "%", 11, 0xFFD4D8CD, false);
        addSpaced(parent, caption, 5, 0);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(max - min);
        seekBar.setProgress(safeInitial - min);
        seekBar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        seekBar.setThumbTintList(ColorStateList.valueOf(ACCENT));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = min + progress;
                caption.setText(label + " · " + value + "%");
                if (fromUser) callback.onChanged(value);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        parent.addView(seekBar, new LinearLayout.LayoutParams(-1, -2));
    }

    private void updatePanelSize() {
        if (panel == null || panelParams == null) return;
        panelParams.width = Math.round(panelWidth() * panelScale);
        panelParams.height = Math.round(panelHeight() * panelScale);
        try {
            windowManager.updateViewLayout(panel, panelParams);
        } catch (IllegalArgumentException exception) {
            stopSelf();
        }
    }

    private void collapsePanel() {
        if (panel == null) return;
        savedX = panelParams.x;
        savedY = panelParams.y;
        try {
            windowManager.removeView(panel);
        } catch (IllegalArgumentException ignored) {
            // The window may already have been detached by Android.
        }
        panel = null;

        TextView icon = makeText("LM", 13, 0xFF10120F, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(roundRect(ACCENT, dp(28), 0xFFD9F99B));
        icon.setElevation(dp(10));
        icon.setOnTouchListener(new BubbleTouchListener());
        bubble = icon;

        WindowManager.LayoutParams bubbleParams = newOverlayParams(dp(56), dp(56));
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = savedX;
        bubbleParams.y = savedY;
        windowManager.addView(bubble, bubbleParams);
        expanded = false;
    }

    private void expandPanel() {
        if (bubble != null) {
            try {
                windowManager.removeView(bubble);
            } catch (IllegalArgumentException ignored) {
                // The bubble may already have been detached.
            }
            bubble = null;
        }
        createPanel();
    }

    private final class PanelDragListener implements View.OnTouchListener {
        private int startX;
        private int startY;
        private float downRawX;
        private float downRawY;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                startX = panelParams.x;
                startY = panelParams.y;
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                panelParams.x = startX + Math.round(event.getRawX() - downRawX);
                panelParams.y = startY + Math.round(event.getRawY() - downRawY);
                savedX = panelParams.x;
                savedY = panelParams.y;
                try {
                    windowManager.updateViewLayout(panel, panelParams);
                } catch (IllegalArgumentException ignored) {
                    return false;
                }
                return true;
            }
            return event.getAction() == MotionEvent.ACTION_UP;
        }
    }

    private final class BubbleTouchListener implements View.OnTouchListener {
        private WindowManager.LayoutParams params;
        private int startX;
        private int startY;
        private float downRawX;
        private float downRawY;
        private boolean moved;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            if (params == null && bubble != null) {
                params = (WindowManager.LayoutParams) bubble.getLayoutParams();
            }
            if (params == null) return false;

            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                startX = params.x;
                startY = params.y;
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                moved = false;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                int dx = Math.round(event.getRawX() - downRawX);
                int dy = Math.round(event.getRawY() - downRawY);
                if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                params.x = startX + dx;
                params.y = startY + dy;
                savedX = params.x;
                savedY = params.y;
                try {
                    windowManager.updateViewLayout(bubble, params);
                } catch (IllegalArgumentException ignored) {
                    return false;
                }
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (!moved) expandPanel();
                return true;
            }
            return true;
        }
    }

    private void startStatsLoop() {
        statsRunnable = new Runnable() {
            @Override
            public void run() {
                if (statsText != null && showStats) {
                    long memoryMb = Debug.getPss() / 1024L;
                    statsText.setText(String.format(
                            Locale.US,
                            "Overlay FPS: %.0f\nOverlay process memory: %d MB",
                            overlayFps,
                            memoryMb
                    ));
                }
                handler.postDelayed(this, 1000L);
            }
        };
        handler.post(statsRunnable);
    }

    @Override
    public void doFrame(long frameTimeNanos) {
        if (previousFrameNanos != 0L) {
            frameCount++;
            long elapsed = frameTimeNanos - previousFrameNanos;
            if (elapsed >= 1_000_000_000L) {
                overlayFps = frameCount * 1_000_000_000.0f / elapsed;
                frameCount = 0;
            }
        }
        previousFrameNanos = frameTimeNanos;
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override
    public void onDestroy() {
        Choreographer.getInstance().removeFrameCallback(this);
        handler.removeCallbacksAndMessages(null);
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) { }
            panel = null;
        }
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) { }
            bubble = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    private static final class DemoEspView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        DemoEspView(Context context) {
            super(context);
            setBackgroundColor(0xFF10140F);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.0f);
            paint.setColor(0xFF30392A);
            canvas.drawRect(1, 1, width - 1, height - 1, paint);

            paint.setColor(ACCENT);
            paint.setStrokeWidth(2.0f);
            canvas.drawRoundRect(width * 0.12f, height * 0.20f, width * 0.36f, height * 0.80f, 5, 5, paint);
            canvas.drawRoundRect(width * 0.59f, height * 0.27f, width * 0.83f, height * 0.77f, 5, 5, paint);

            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(10.0f * getResources().getDisplayMetrics().density);
            canvas.drawText("DEMO TARGET 01", width * 0.12f, height * 0.15f, paint);
            canvas.drawText("DEMO TARGET 02", width * 0.59f, height * 0.22f, paint);

            paint.setColor(0xFF7E8873);
            paint.setTypeface(Typeface.DEFAULT);
            paint.setTextSize(9.0f * getResources().getDisplayMetrics().density);
            canvas.drawText("Illustrative overlay only", dp(10), height - dp(8), paint);
        }

        private int dp(float value) {
            return Math.round(value * getResources().getDisplayMetrics().density);
        }
    }
}
