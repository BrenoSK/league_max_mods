package com.leaguemax.mods;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF10120F);
        getWindow().setNavigationBarColor(0xFF10120F);
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.TOP);
        root.setPadding(dp(24), dp(38), dp(24), dp(24));
        root.setBackgroundColor(0xFF10120F);

        TextView title = new TextView(this);
        title.setText("LEAGUE MAX Mods");
        title.setTextColor(0xFFF3F4EF);
        title.setTextSize(26);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Floating utility overlay · local visual demo");
        subtitle.setTextColor(0xFF9A9D94);
        subtitle.setTextSize(13);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(8);
        subtitleParams.bottomMargin = dp(28);
        root.addView(subtitle, subtitleParams);

        Button activate = new Button(this);
        activate.setText("ACTIVATE FLOATING MENU");
        activate.setAllCaps(false);
        activate.setTextSize(14);
        activate.setOnClickListener(v -> activateOverlay());
        root.addView(activate, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView info = new TextView(this);
        info.setText("The ESP panel contains sample boxes drawn inside this utility only. It does not inspect or modify League Max.\n\n1. Allow Display over other apps.\n2. Return to this app.\n3. Tap ACTIVATE FLOATING MENU again.\n4. Use the floating panel or its LM bubble.");
        info.setTextColor(0xFFB7BAAF);
        info.setTextSize(14);
        info.setLineSpacing(dp(4), 1.0f);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(-1, -2);
        infoParams.topMargin = dp(24);
        root.addView(info, infoParams);

        setContentView(root);
    }

    private void activateOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permissionIntent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(permissionIntent);
            return;
        }

        Intent serviceIntent = new Intent(this, FloatingOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        finish();
    }
}
