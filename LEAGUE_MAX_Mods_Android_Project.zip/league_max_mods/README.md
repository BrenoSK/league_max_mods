# LEAGUE MAX Mods — Floating Overlay

Android Studio project. This app provides an independent, user-controlled floating overlay. Its ESP panel is a static visual demonstration and does not inspect or interact with League Max, another app's memory, rendering pipeline, network traffic, or process.

## Build environment
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (Android Studio can provision this)
- JDK: 17
- compileSdk: 35
- minSdk: 23
- targetSdk: 35
- Java: 17
- Device target: Android ARM64 (the app is Java-only and runs on ARM64 and ARMv7)
- Runtime dependencies: Android SDK only; no third-party libraries

## Build
Open this directory in Android Studio, install Android SDK Platform 35 and Build Tools 35.0.0, then run:

```bash
gradle --version
gradle :app:assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Install
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell monkey -p com.leaguemax.mods 1
```

Tap **ACTIVATE FLOATING MENU**, grant **Display over other apps**, then activate again. On Android 13+, allow the foreground-service notification if prompted.

## Included
- Draggable floating panel and draggable collapsed bubble
- Collapse / expand and close controls
- Demonstration ESP boxes
- Overlay frame-rate measurement and process PSS memory display
- Opacity and scale sliders
- Local-only UI switches

## Scope
No game injection, memory modification, anti-cheat bypass, gameplay automation, or packet interception is implemented.
