package com.leaguemax.mods;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Debug;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.FrameLayout;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

public final class FloatingOverlayService extends Service implements Choreographer.FrameCallback {
    private static final String CHANNEL = "league_max_overlay";
    private WindowManager windowManager;
    private WindowManager.LayoutParams windowParams;
    private LinearLayout panel;
    private View bubble;
    private TextView statsText;
    private DemoEspView espView;
    private boolean expanded = true;
    private boolean showEsp = true;
    private boolean showStats = true;
    private float panelAlpha = 0.96f;
    private float panelScale = 1.0f;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastFrameNanos;
    private int frames;
    private float measuredFps;
    private long lastCpuTime;
    private long lastWallTime;
    private Runnable statsRunnable;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private int color(String hex) { return Color.parseColor(hex); }

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) startForeground(71, notification);
        else startForeground(71, notification);
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        createOverlay();
        Choreographer.getInstance().postFrameCallback(this);
        startStatsLoop();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "LEAGUE MAX Mods", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the floating utility menu active");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("LEAGUE MAX Mods")
                .setContentText("Floating menu active").setOngoing(true).build();
        return new Notification.Builder(this).setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("LEAGUE MAX Mods").setContentText("Floating menu active").setOngoing(true).build();
    }

    private WindowManager.LayoutParams baseParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
    }

    private void createOverlay() {
        panel = buildPanel();
        windowParams = baseParams(dp(292), dp(440));
        windowParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowParams.x = dp(18); windowParams.y = dp(110);
        windowManager.addView(panel, windowParams);
    }

    private LinearLayout buildPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackground(roundRect(0xF0141712, dp(16)));
        outer.setElevation(dp(12));
        outer.setAlpha(panelAlpha);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(8), dp(10));
        header.setBackground(roundRect(0xFF20251C, dp(14)));
        TextView title = text("LEAGUE MAX Mods", 14, 0xFFF2F4EC, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView collapse = action("—");
        collapse.setOnClickListener(v -> collapsePanel());
        header.addView(collapse, new LinearLayout.LayoutParams(dp(34), dp(30)));
        TextView close = action("×");
        close.setOnClickListener(v -> stopSelf());
        header.addView(close, new LinearLayout.LayoutParams(dp(34), dp(30)));
        header.setOnTouchListener(new DragListener());
        outer.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14), dp(10), dp(14), dp(14));
        TextView section = text("VISUAL DEMO", 10, 0xFFB8F35A, true); addSpaced(content, section, 0, 8);
        Switch espSwitch = switchRow("ESP sample boxes", showEsp, checked -> { showEsp = checked; if (espView != null) espView.invalidate(); });
        content.addView(espSwitch);
        espView = new DemoEspView(this); espView.setVisibility(showEsp ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(118)); ep.topMargin = dp(8); content.addView(espView, ep);

        addSpaced(content, text("PERFORMANCE", 10, 0xFFB8F35A, true), 14, 6);
        Switch statsSwitch = switchRow("FPS and memory", showStats, checked -> { showStats = checked; statsText.setVisibility(checked ? View.VISIBLE : View.GONE); });
        content.addView(statsSwitch);
        statsText = text("Overlay FPS: --\nApp memory: -- MB", 12, 0xFFD4D8CD, false);
        addSpaced(content, statsText, 6, 4);

        addSpaced(content, text("ADJUSTMENTS", 10, 0xFFB8F35A, true), 14, 6);
        addSlider(content, "Panel opacity", 35, 100, 96, value -> { panelAlpha = value / 100f; panel.setAlpha(panelAlpha); });
        addSlider(content, "Panel scale", 75, 125, 100, value -> { panelScale = value / 100f; applyScale(); });
        addSpaced(content, text("Local UI demonstration · no game process access", 10, 0xFF777D70, false), 12, 0);
        scroll.addView(content); outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return outer;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int fill, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(fill); d.setCornerRadius(radius); d.setStroke(dp(1), 0xFF343B2E); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }

    private TextView action(String value) {
        TextView t = text(value, 20, 0xFFE9EDE2, true); t.setGravity(Gravity.CENTER); t.setBackground(roundRect(0xFF30372A, dp(9))); return t;
    }

    private void addSpaced(LinearLayout parent, View view, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); p.bottomMargin = dp(bottom); parent.addView(view, p);
    }

    private interface BoolChanged { void changed(boolean checked); }
    private Switch switchRow(String label, boolean checked, BoolChanged listener) {
        Switch s = new Switch(this); s.setText(label); s.setTextColor(0xFFE1E5D9); s.setTextSize(12); s.setChecked(checked);
        s.setOnCheckedChangeListener((button, value) -> listener.changed(value)); return s;
    }

    private interface ValueChanged { void changed(int value); }
    private void addSlider(LinearLayout parent, String label, int min, int max, int initial, ValueChanged callback) {
        TextView caption = text(label + " · " + initial, 11, 0xFFD4D8CD, false); addSpaced(parent, caption, 5, 0);
        SeekBar seek = new SeekBar(this); seek.setMax(max - min); seek.setProgress(initial - min);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFB8F35A));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFB8F35A));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = min + progress; caption.setText(label + " · " + value); if (fromUser) callback.changed(value);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        }); parent.addView(seek);
    }

    private void applyScale() {
        if (panel == null || windowParams == null) return;
        windowParams.width = dp((int)(292 * panelScale)); windowParams.height = dp((int)(440 * panelScale));
        try { windowManager.updateViewLayout(panel, windowParams); } catch (IllegalArgumentException ignored) { }
    }

    private void collapsePanel() {
        if (panel != null) { try { windowManager.removeView(panel); } catch (IllegalArgumentException ignored) { } panel = null; }
        bubble = new TextView(this); ((TextView)bubble).setText("LM"); ((TextView)bubble).setTextColor(0xFF10120F);
        ((TextView)bubble).setTextSize(13); ((TextView)bubble).setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        ((TextView)bubble).setGravity(Gravity.CENTER); bubble.setBackground(roundRect(0xFFB8F35A, dp(28))); bubble.setElevation(dp(10));
        WindowManager.LayoutParams bp = baseParams(dp(56), dp(56)); bp.gravity = Gravity.TOP | Gravity.LEFT; bp.x = windowParams.x; bp.y = windowParams.y;
        bubble.setOnClickListener(v -> expandPanel()); bubble.setOnTouchListener(new BubbleDragListener(bp));
        windowManager.addView(bubble, bp); expanded = false;
    }

    private void expandPanel() {
        if (bubble != null) { try { windowManager.removeView(bubble); } catch (IllegalArgumentException ignored) { } bubble = null; }
        panel = buildPanel(); windowParams = baseParams(dp((int)(292 * panelScale)), dp((int)(440 * panelScale)));
        windowParams.gravity = Gravity.TOP | Gravity.LEFT; windowParams.x = dp(18); windowParams.y = dp(110);
        windowManager.addView(panel, windowParams); expanded = true;
    }

    private final class DragListener implements View.OnTouchListener {
        private int startX, startY; private float downX, downY;
        @Override public boolean onTouch(View v, MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { startX = windowParams.x; startY = windowParams.y; downX = e.getRawX(); downY = e.getRawY(); return true; }
            if (e.getAction() == MotionEvent.ACTION_MOVE) { windowParams.x = startX + (int)(e.getRawX() - downX); windowParams.y = startY + (int)(e.getRawY() - downY); try { windowManager.updateViewLayout(panel, windowParams); } catch (IllegalArgumentException ignored) { } return true; }
            return e.getAction() == MotionEvent.ACTION_UP;
        }
    }

    private final class BubbleDragListener implements View.OnTouchListener {
        private final WindowManager.LayoutParams params; private int x, y; private float dx, dy;
        BubbleDragListener(WindowManager.LayoutParams p) { params = p; }
        @Override public boolean onTouch(View v, MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { x = params.x; y = params.y; dx = e.getRawX(); dy = e.getRawY(); return true; }
            if (e.getAction() == MotionEvent.ACTION_MOVE) { params.x = x + (int)(e.getRawX()-dx); params.y = y + (int)(e.getRawY()-dy); try { windowManager.updateViewLayout(bubble, params); } catch (IllegalArgumentException ignored) { } return true; }
            if (e.getAction() == MotionEvent.ACTION_UP) { if (Math.abs(e.getRawX()-dx) < dp(8) && Math.abs(e.getRawY()-dy) < dp(8)) expandPanel(); return true; }
            return false;
        }
    }

    private void startStatsLoop() {
        statsRunnable = new Runnable() {
            @Override public void run() {
                if (statsText != null && showStats) {
                    long pssMb = Debug.getPss() / 1024;
                    statsText.setText(String.format(Locale.US, "Overlay FPS: %.0f\nApp memory: %d MB", measuredFps, pssMb));
                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(statsRunnable);
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (lastFrameNanos != 0) {
            frames++;
            long elapsed = frameTimeNanos - lastFrameNanos;
            if (elapsed >= 1_000_000_000L) { measuredFps = frames * 1_000_000_000f / elapsed; frames = 0; }
        }
        lastFrameNanos = frameTimeNanos;
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        Choreographer.getInstance().removeFrameCallback(this); handler.removeCallbacksAndMessages(null);
        if (panel != null) { try { windowManager.removeView(panel); } catch (Exception ignored) { } panel = null; }
        if (bubble != null) { try { windowManager.removeView(bubble); } catch (Exception ignored) { } bubble = null; }
        super.onDestroy();
    }

    private static final class DemoEspView extends View {
        private final Paint p = new Paint(3);
        DemoEspView(Context context) { super(context); setBackgroundColor(0xFF10140F); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w = getWidth(), h = getHeight();
            p.setColor(0xFF30392A); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); c.drawRect(1,1,w-1,h-1,p);
            p.setColor(0xFFB8F35A); p.setStrokeWidth(2); p.setStyle(Paint.Style.STROKE);
            c.drawRoundRect(w*.12f,h*.18f,w*.36f,h*.82f,5,5,p); c.drawRoundRect(w*.58f,h*.25f,w*.82f,h*.78f,5,5,p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(10); p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("DEMO TARGET 01",w*.12f,h*.13f,p); c.drawText("DEMO TARGET 02",w*.58f,h*.20f,p);
            p.setColor(0xFF7E8873); p.setTextSize(9); p.setTypeface(Typeface.DEFAULT); c.drawText("Illustrative overlay only",dpStatic(10),h-8,p);
        }
        private int dpStatic(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    }
}
