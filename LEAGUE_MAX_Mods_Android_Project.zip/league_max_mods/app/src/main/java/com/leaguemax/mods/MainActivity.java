package com.leaguemax.mods;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF10120F);
        getWindow().setNavigationBarColor(0xFF10120F);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        root.setBackgroundColor(0xFF10120F);
        TextView title = new TextView(this);
        title.setText("LEAGUE MAX Mods"); title.setTextColor(0xFFF3F4EF); title.setTextSize(25); title.setTypeface(null, 1);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Floating utility overlay · local demonstration only"); sub.setTextColor(0xFF9A9D94); sub.setTextSize(13);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(8); sp.bottomMargin = dp(28); root.addView(sub, sp);
        Button launch = new Button(this); launch.setText("ACTIVATE FLOATING MENU"); launch.setAllCaps(false);
        launch.setOnClickListener(v -> activateOverlay());
        root.addView(launch, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView note = new TextView(this);
        note.setText("The ESP panel draws sample boxes inside the overlay. It does not read, modify, or inject into League Max.\n\nGrant “Display over other apps” when Android requests it. On Android 13+, allow notifications so the foreground service remains visible.");
        note.setTextColor(0xFFB7BAAF); note.setTextSize(14); note.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(24); root.addView(note, np);
        setContentView(root);
    }

    private void activateOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            return;
        }
        Intent service = new Intent(this, FloatingOverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        finish();
    }
}
